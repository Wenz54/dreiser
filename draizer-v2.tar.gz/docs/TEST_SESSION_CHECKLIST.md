# ✅ **ЧЕКЛИСТ ТЕСТОВОЙ СЕССИИ V1.3.07**

**Дата:** 2025-10-26  
**Версия:** 1.3.07 (После глубокого рефакторинга)  
**Цель:** Проверить что рефакторинг работает!

---

## 📊 **МОНИТОРИНГ В РЕАЛЬНОМ ВРЕМЕНИ**

### **🕐 Каждые 15 минут проверяй:**

#### **1. КОЛИЧЕСТВО СДЕЛОК:**
```
✅ ХОРОШО: 1-2 сделки за 15 минут (4-8 за час)
⚠️ СОМНИТЕЛЬНО: 3-4 сделки за 15 минут (12-16 за час)
❌ ПЛОХО: 5+ сделок за 15 минут (20+ за час) - пороги НЕ работают!
```

**Где смотреть:**
- Frontend → Portfolio → Recent Trades
- Или Dashboard → Total Trades (должно расти медленно)

---

#### **2. ВИНРЕЙТ:**
```
✅ ОТЛИЧНО: >= 50%
⚠️ НОРМ: 45-50%
❌ ПЛОХО: < 45% (как раньше)
```

**Где смотреть:**
- Dashboard → Win Rate %

---

#### **3. P&L ТРЕНД:**
```
✅ ХОРОШО: Медленный рост вверх
⚠️ НОРМ: Около нуля (±$0.5)
❌ ПЛОХО: Падает вниз
```

**Где смотреть:**
- Dashboard → Total P&L

---

#### **4. ТИПЫ СДЕЛОК:**
```
✅ ХОРОШО: Микс из BUY/LONG/SHORT (разнообразие)
⚠️ СОМНИТЕЛЬНО: Только SHORT или только BUY
❌ ПЛОХО: Все сделки одного типа
```

**Где смотреть:**
- Portfolio → Recent Trades → Type column

---

## 🔍 **СПЕЦИАЛЬНЫЕ ПРОВЕРКИ**

### **A. ПРОВЕРКА: AI НЕ БОИТСЯ BNBUSDT**

**Что проверить:**
- Есть ли сделки на BNBUSDT?
- Если да → ✅ Страх убран!
- Если нет через 1 час → ⚠️ Возможно рынок просто не подходит

**Команда для проверки (через PowerShell):**
```powershell
docker-compose exec -T postgres psql -U draizer_user -d draizer_db -c "
SELECT symbol, COUNT(*) as trades
FROM transactions
WHERE created_at > NOW() - INTERVAL '2 hours'
GROUP BY symbol
ORDER BY trades DESC;"
```

---

### **B. ПРОВЕРКА: ПОРОГИ 60%/65% РАБОТАЮТ**

**Что проверить:**
- Мало ли "быстрых убытков за 1-2 минуты"?
- Если много (>30%) → ❌ Пороги НЕ работают
- Если мало (<20%) → ✅ Пороги работают!

**Команда для проверки:**
```powershell
docker-compose exec -T postgres psql -U draizer_user -d draizer_db -c "
SELECT 
  COUNT(*) as total,
  COUNT(*) FILTER (WHERE duration_minutes <= 2 AND was_profitable = false) as quick_losses,
  ROUND(COUNT(*) FILTER (WHERE duration_minutes <= 2 AND was_profitable = false)::numeric / COUNT(*) * 100, 1) as quick_loss_pct
FROM ai_learning_notes
WHERE created_at > NOW() - INTERVAL '2 hours';"
```

**Интерпретация:**
- `quick_loss_pct` < 20% → ✅ Хорошо (AI не открывает слабые позиции)
- `quick_loss_pct` > 30% → ❌ Плохо (всё ещё "ложные сигналы")

---

### **C. ПРОВЕРКА: LEARNING NOTES КАЧЕСТВЕННЫЕ**

**Что проверить:**
- Уроки конкретные? (с метриками, timing)
- Уроки НЕ упоминают "плохой символ" или "низкий винрейт"?

**Команда для проверки:**
```powershell
docker-compose exec -T postgres psql -U draizer_user -d draizer_db -c "
SELECT 
  created_at,
  symbol,
  CASE WHEN was_profitable THEN 'WIN' ELSE 'LOSS' END as result,
  lesson_learned
FROM ai_learning_notes
WHERE created_at > NOW() - INTERVAL '2 hours'
ORDER BY created_at DESC
LIMIT 10;"
```

**Ищи:**
- ✅ ХОРОШО: "ВХОД ПРИ 5M +0.1% = СЛАБО! ТРЕБУЕТСЯ >= +0.5%"
- ❌ ПЛОХО: "ПРОБЛЕМНЫЙ АКТИВ" или "НИЗКИЙ ВИНРЕЙТ"

---

## 📈 **ИТОГИ ПОСЛЕ 2 ЧАСОВ**

### **Команда для полной статистики:**
```powershell
docker-compose exec -T postgres psql -U draizer_user -d draizer_db -c "
SELECT 
  COUNT(*) as total_trades,
  COUNT(*) FILTER (WHERE was_profitable = true) as wins,
  COUNT(*) FILTER (WHERE was_profitable = false) as losses,
  ROUND(COUNT(*) FILTER (WHERE was_profitable = true)::numeric / NULLIF(COUNT(*), 0) * 100, 1) as winrate,
  ROUND(SUM(pnl_percent), 2) as total_pnl_pct,
  ROUND(AVG(pnl_percent), 3) as avg_pnl_pct
FROM ai_learning_notes
WHERE created_at > NOW() - INTERVAL '2 hours';"
```

---

## ✅ **КРИТЕРИИ УСПЕХА (2 ЧАСА):**

```
┌──────────────────────┬──────────────┬──────────────┐
│ Метрика              │ Цель (min)   │ Идеал        │
├──────────────────────┼──────────────┼──────────────┤
│ Винрейт              │ >= 45%       │ >= 50%       │
│ Сделок за 2ч         │ 8-16         │ 10-12        │
│ P&L                  │ >= -$1       │ >= +$2       │
│ BNBUSDT trades       │ >= 1         │ >= 2         │
│ Quick losses (<2min) │ < 30%        │ < 20%        │
│ Avg trade duration   │ 5-15 min     │ 8-12 min     │
└──────────────────────┴──────────────┴──────────────┘
```

---

## 🚨 **КРАСНЫЕ ФЛАГИ (СТОП СЕССИЯ!):**

**Останови сессию если:**
1. ❌ **>20 сделок за 2 часа** (пороги не работают!)
2. ❌ **Винрейт < 35%** (как раньше, рефакторинг не помог)
3. ❌ **P&L < -$3** (слишком большой убыток)
4. ❌ **Много "quick losses"** (>40% сделок <2min убыточны)

---

## 📝 **ЗАМЕТКИ ВО ВРЕМЯ СЕССИИ:**

### **Время: _____**
- Сделок: _____
- Винрейт: _____%
- P&L: $______
- Наблюдения: ___________________________

### **Время: _____**
- Сделок: _____
- Винрейт: _____%
- P&L: $______
- Наблюдения: ___________________________

### **Время: _____**
- Сделок: _____
- Винрейт: _____%
- P&L: $______
- Наблюдения: ___________________________

---

## 🎯 **ПОСЛЕ СЕССИИ:**

**Если успешно (винрейт >= 45%, P&L >= -$1):**
→ Запустить ДЛИННУЮ сессию (8-12 часов)

**Если провал (винрейт < 40%, P&L < -$2):**
→ Дополнительный анализ и fine-tuning

---

**УДАЧИ! 🚀**

