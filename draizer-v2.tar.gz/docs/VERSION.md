# DRAIZER VERSION CONTROL

**Текущая версия**: `1.3.05`

## 📋 ПРАВИЛА ВЕРСИОНИРОВАНИЯ

Формат версии: `X.Y.ZZ`

- **X** = Major version (кардинальные изменения архитектуры)
- **Y** = Minor version (новые фичи, улучшения)
- **ZZ** = Patch version (багфиксы, мелкие правки)

---

## 🔄 КАК ОБНОВЛЯТЬ ВЕРСИЮ

### При каждом обновлении:
1. **Увеличь третью цифру (ZZ) на 1**
   - `1.3.02` → `1.3.03`
   - `1.3.09` → `1.3.10`

2. **Если третья цифра достигла 10:**
   - Увеличь вторую цифру (Y) на 1
   - Сбрось третью цифру (ZZ) на 00
   - `1.3.10` → `1.4.00`

3. **Обнови в двух местах:**
   - `frontend/src/components/Layout.tsx` (строка 93)
   - `backend/app/core/config.py` (строка 19)

---

## 📝 ИСТОРИЯ ВЕРСИЙ

### v1.3.05 (2024-10-24)
- 🔥 **КРИТИЧЕСКИЙ БАГФИКС**: Добавлен ПОЛНЫЙ FUTURES функционал (был полностью отсутствовал!)
  - **Проблема**: LONG/SHORT/CLOSE_LONG/CLOSE_SHORT НЕ ОБРАБАТЫВАЛИСЬ вообще!
  - **Решение**: 
    - Добавлен импорт FuturesTradingService и ai_service_optimized_v2
    - Добавлен DecisionType mapping для всех FUTURES actions
    - Добавлена логика should_execute для FUTURES (60% confidence, 1.3 R:R)
    - Добавлено исполнение LONG/SHORT/CLOSE_LONG/CLOSE_SHORT
  - **Файлы**: `backend/app/services/trading_service.py` (строки 8-20, 47, 579-593, 629-645, 686-705, 749-843)
- 🎯 **R:R расчет для SHORT исправлен**
  - SHORT теперь использует инвертированную формулу: `(current-target)/(stop-current)`
  - **Файл**: `backend/app/services/trading_service.py` (строки 579-593)
- 💎 **UI**: Исправлено отображение цен (защита от undefined)
  - Добавлены проверки `? ... : 'N/A'` для current_price, target_price, stop_loss
  - **Файл**: `frontend/src/pages/AISession.tsx`

### v1.3.04 (2024-10-24)
- 🐛 **КРИТИЧЕСКИЙ БАГФИКС**: Исправлено закрытие FUTURES позиций (правильные аргументы)
  - **Проблема**: TypeError - передавались неверные аргументы в `close_position()`
  - **Решение**: Исправлен вызов с `(position, price, reason)` на `(portfolio, position)`
  - **Файл**: `backend/app/services/trading_service.py` (строки 951-989)
- 💎 **UI**: Полная точность цен (6 знаков после запятой)
  - **Файл**: `frontend/src/pages/AISession.tsx` (цены: current, target, stop_loss)
- 🎯 **UI**: Визуализация отклоненных FUTURES решений
  - Показывает причину отклонения: Poor R:R / Low Confidence / WAIT
  - Элегантные chips с иконками и opacity
  - **Файл**: `frontend/src/pages/AISession.tsx` (функция `getRejectionReason`)

### v1.3.03 (2024-10-24)
- 🐛 **КРИТИЧЕСКИЙ БАГФИКС**: Исправлено закрытие FUTURES позиций (CLOSE_SHORT/CLOSE_LONG)
  - **Проблема**: AI не предоставлял `current_price`, закрытие не исполнялось
  - **Решение**: Получаем актуальную цену с Binance вместо полагания на AI
  - **Файл**: `backend/app/services/trading_service.py` (строки 963-1001)

### v1.3.02 (2024-10-24)
- ✅ R:R фильтр вернул на 1.3:1
- ✅ Добавлена визуализация отклоненных решений
- ✅ Элитарный черно-белый UI
- ✅ Win rate исправлен (считается от закрытых сделок)
- ✅ Автозакрытие позиций перед концом сессии (90/60 min)
- ✅ Оптимизация промпта v2 (-43% токенов)
- ✅ RESET теперь удаляет futures

### v1.2.0 (ранее)
- GPT Performance Monitor
- News Relevance Scorer
- Universal Context Manager

### v1.1.0 (ранее)
- Telegram News Monitor
- Context Compression
- Enhanced Security

### v1.0.0 (MVP)
- Базовая функциональность
- AI trading
- Virtual portfolio

---

## 🚀 СЛЕДУЮЩИЕ ВЕРСИИ

### v1.4.00 (будущее)
- После 10 патчей в v1.3.xx
- Планируемые major фичи...

### v2.0.00 (далекое будущее)
- Кардинальные изменения архитектуры
- Real trading integration?
- Mobile apps?

---

**Последнее обновление**: 2024-10-24  
**Обновлено до**: v1.3.05

