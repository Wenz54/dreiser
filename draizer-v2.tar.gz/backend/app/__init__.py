"""Draizer AI Trading Platform - Backend"""
__version__ = "1.0.0"






