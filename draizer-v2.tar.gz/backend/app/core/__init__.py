"""Core configuration and security modules"""






