"""Pydantic schemas for API validation"""






