"""Utility functions"""












