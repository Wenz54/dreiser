# 🔑 API КЛЮЧИ ДЛЯ ТЕСТИРОВАНИЯ (FREE!)

## 📋 **ГДЕ ВСТАВЛЯТЬ:**

Файл: **`backend/c_engine/config/engine.json`**

Найди `═══ ВСТАВЬ ЗДЕСЬ ═══` и замени на свои ключи!

---

## 🚀 **3 FREE TESTNETS (БЕЗ РЕАЛЬНЫХ ДЕНЕГ!):**

Для тестирования тебе нужны только **3 testnet биржи**. Это **абсолютно бесплатно** и **без реальных денег**!

---

### 1. Binance Testnet ⭐

**URL:** https://testnet.binance.vision/

**Почему:** Лучшая ликвидность, быстрый WebSocket

**Шаги:**
1. Нажми **"Log in with GitHub"**
2. Авторизуйся через GitHub (если нет аккаунта - создай за 2 мин)
3. Перейди в **"API Keys"** → **"Generate HMAC_SHA256 Key"**
4. Скопируй:
   - **API Key**
   - **Secret Key**

**ВСТАВЬ В `engine.json`:**
```json
"binance": {
  "testnet": {
    "api_key": "abc123def456ghi789jklmno...",
    "api_secret": "xyz987wvu654tsr321qponml..."
  }
}
```

**Время:** 3-5 минут  
**Стоимость:** FREE ✅

---

### 2. Bybit Testnet ⭐

**URL:** https://testnet.bybit.com/

**Почему:** 100 BTC testnet баланс бесплатно! + быстрая биржа

**Шаги:**
1. **Register** через email (любой email)
2. Подтверди email
3. Получи **100 BTC testnet** автоматически! 🎉
4. Перейди: **API Keys** → **Create New Key**
5. Выбери **"Unified Trading Account"**
6. Включи **"Spot Trading"**
7. Скопируй ключи

**ВСТАВЬ В `engine.json`:**
```json
"bybit": {
  "testnet": {
    "api_key": "def789ghi012jkl345mno567...",
    "api_secret": "uvw345xyz678abc901def234..."
  }
}
```

**Время:** 5-7 минут  
**Стоимость:** FREE + 100 BTC testnet! ✅

---

### 3. OKX Demo ⭐

**URL:** https://www.okx.com/account/my-api

**Почему:** Demo mode = виртуальные деньги, надежная биржа

**Шаги:**
1. **Register** на OKX (email + password)
2. Подтверди email
3. В настройках включи **"Demo Trading"** mode
4. Перейди: **Account** → **API** → **Create API Key**
5. **ВАЖНО:** Установи **Passphrase** (8-32 символа, придумай любой!)
   - Например: `TestPass123!`
6. Включи **"Trade"** permission
7. Скопируй **все 3 значения**:
   - API Key
   - Secret Key
   - Passphrase

**ВСТАВЬ В `engine.json`:**
```json
"okx": {
  "testnet": {
    "api_key": "jkl456mno789pqr012stu345...",
    "api_secret": "pqr012stu345vwx678yza901...",
    "api_passphrase": "TestPass123!"
  }
}
```

**Время:** 5-7 минут  
**Стоимость:** FREE ✅

---

## 📝 **EXAMPLE: Заполненный engine.json**

```json
{
  "exchanges": {
    "binance": {
      "enabled": true,
      "testnet": {
        "api_key": "f2d8e9b1c3a4d5e6f7g8h9i0j1k2l3m4",
        "api_secret": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
      }
    },
    
    "bybit": {
      "enabled": true,
      "testnet": {
        "api_key": "z9y8x7w6v5u4t3s2r1q0p9o8n7m6l5k4",
        "api_secret": "m4n5o6p7q8r9s0t1u2v3w4x5y6z7a8b9"
      }
    },
    
    "okx": {
      "enabled": true,
      "testnet": {
        "api_key": "12345678-abcd-efgh-ijkl-mnopqrstuvwx",
        "api_secret": "ABCD1234EFGH5678IJKL9012MNOP3456",
        "api_passphrase": "MyTestPass123!"
      }
    }
  }
}
```

---

## ⚠️ **ВАЖНЫЕ НАСТРОЙКИ API КЛЮЧЕЙ:**

### ✅ ЧТО ВКЛЮЧИТЬ:
- **Spot Trading** / **Trade** - для торговли
- **Read** - для чтения данных

### ❌ ЧТО НЕ ВКЛЮЧАТЬ:
- **Withdrawals** - снятие средств (НЕ НУЖНО!)
- **Transfer** - переводы (НЕ НУЖНО!)
- **Margin Trading** - маржа (НЕ НУЖНО!)

### 🔒 Безопасность:
- ❌ **НИКОГДА** не коммить ключи в Git!
- ✅ Это testnet ключи → не страшно, но всё равно не светить
- ✅ Включи 2FA на биржах (если есть)

---

## 📊 **ЧТО ТЫ ПОЛУЧИШЬ:**

```
3 Testnet биржи:
├─ Binance testnet  ✅
├─ Bybit testnet    ✅
└─ OKX demo         ✅

= 3 пары арбитража
= FREE тестирование
= 0 реальных денег
= Полноценная проверка системы!
```

**Формула:** 3 биржи → 3×2/2 = **3 пары арбитража**

**Примеры:**
- Binance vs Bybit: BTCUSDT
- Binance vs OKX: ETHUSDT
- Bybit vs OKX: BNBUSDT

---

## ✅ **CHECKLIST:**

### Получение ключей:
- [ ] Binance testnet ключи получены (3-5 мин)
- [ ] Bybit testnet ключи получены (5-7 мин)
- [ ] OKX demo ключи получены (5-7 мин)

### Вставка в конфиг:
- [ ] Все 3 биржи добавлены в `engine.json`
- [ ] Проверил что нет опечаток
- [ ] Сохранил файл

### Права API:
- [ ] Binance: "Spot Trading" включен
- [ ] Bybit: "Spot Trading" включен
- [ ] OKX: "Trade" включен
- [ ] Withdrawals ВЫКЛЮЧЕНЫ везде

### Тестирование:
- [ ] Бот запускается без ошибок
- [ ] Все 3 биржи подключаются
- [ ] Price feed работает
- [ ] Видны opportunities

---

## 🚀 **NEXT STEP: BUILD & RUN**

После вставки ключей:

```bash
cd backend/c_engine

# Build
mkdir -p build && cd build
cmake .. && make -j$(nproc)

# Run
./draizer_engine
```

**Expected output:**
```
🌐 Initializing Binance...
   ✓ Binance connected
🌐 Initializing Bybit...
   ✓ Bybit connected
🌐 Initializing OKX...
   ✓ OKX connected

✅ Connected to 3 exchange(s)

💰 OPPORTUNITY: BTCUSDT | Buy @67,000 (binance) → Sell @67,050 (bybit) | 
   Spread: 74.63 bps | Profit: $3.73
```

---

## 💡 **FAQ:**

**Q: Можно ли потерять реальные деньги?**  
A: **НЕТ!** Это testnet/demo - виртуальные деньги. 0 риска! ✅

**Q: Сколько это стоит?**  
A: **$0** - абсолютно бесплатно! ✅

**Q: Сколько времени займет получение ключей?**  
A: **15-20 минут** на все 3 биржи

**Q: Нужен ли KYC (верификация документов)?**  
A: **НЕТ** для testnets! Только email

**Q: Что если забуду Passphrase (OKX)?**  
A: Просто создай новый API ключ с новым passphrase

**Q: Можно ли добавить больше бирж потом?**  
A: **ДА!** Когда будешь готов к real trading:
- MEXC (maker rebates -0.01%!)
- Gate.io, KuCoin, Huobi, Bitget
- Каждая = $10-20 минимум

---

## 🎯 **READY!**

**Время на setup:** 15-20 минут  
**Стоимость:** $0 (FREE!)  
**Риск:** 0% (testnet only)  
**Результат:** Полноценная тестовая среда с 3 биржами!

**ЕБАШИМ ТЕСТЫ! 🚀**

---

## 📞 **TROUBLESHOOTING:**

**"API key invalid"**
→ Проверь что скопировал без пробелов
→ Проверь что включил "Spot Trading"

**"Insufficient permissions"**
→ Включи "Trade" / "Spot Trading" в настройках ключа

**"Connection refused"**
→ Проверь интернет
→ Проверь что URL правильный (testnet, не main!)

**"OKX passphrase required"**
→ OKX требует 3 значения: key + secret + passphrase
→ Passphrase придумываешь сам при создании ключа

---

**TOTAL TIME: 15-20 минут → готов к тестам! ⚡**
